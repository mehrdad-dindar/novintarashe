CKEDITOR.plugins.setLang( 'html5video', 'zh-cn', {
    button: '发布HTML5视频',
    title: 'HTML5视频',
    infoLabel: '视频信息',
    allowed: '支持格式: MP4, WebM, Ogv',
    urlMissing: '视频url',
    videoProperties: '视频属性',
    upload: '上传视频',
    btnUpload: '上传',
    advanced: '高级',
    autoplay: '自动播放',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: '是',
    no: '否',
    responsive: '自动宽度',
    controls: '显示控件？'
} );
