$('.product-category').select2ToTree({
    rtl: true,
    width: '100%',
    placeholder: "انتخاب کنید",
});
